# ProjetoIntegrador-3.1
Projeto Integrador da PUC-CAMPINAS, aplicativo feito em KOTLIN

O aplicativo consiste em criar um registro de ponto, com objetivo de facilitar o registro de saida
e entrada dos colaboradores da PUC-CAMPINAS.

Neste aplicativo, o usuário poderá registrar seu ponto de forma simples e rápida, utilizando 
seu dispositivo móvel.

  Seus objetivos especificos são: 
  
    -Exigir que o funcionário crie o seu calendário semanal de atividades
    -Promover um modelo de autenticação de usuário
    -Registro de presença por turno através do aplicativo, utilizando geolocalização para garantir o registro somente no local de trabalho
    -Configurar um alerta para mostrar ao usuário como lembrete que tem que bater o ponto
    -Relatório de horas trabalhadas que poderá ser gerado pelo usuário
    


Aplicativo em constante atualização pelo grupo. 
